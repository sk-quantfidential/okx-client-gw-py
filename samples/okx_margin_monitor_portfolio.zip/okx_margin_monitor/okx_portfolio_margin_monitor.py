#!/usr/bin/env python3
"""
OKX Portfolio Margin Mode - Delta-Neutral Position Monitor

This monitor is specifically designed for Portfolio Margin mode with 
Spot-Derivatives Risk Offset enabled.

KEY DIFFERENCE FROM MULTI-CURRENCY MODE:
- Portfolio Margin RECOGNIZES the hedge between spot and derivatives
- Margin is calculated via stress tests (MR1-MR9), not gross exposure
- For delta-neutral positions, MR1 (spot shock) is near zero
- The binding constraint becomes MR4 (basis risk) or MR7 (minimum charge)

For a spot BTC + short BTC-USDT-SWAP position:
- Your spot is "included" in the risk unit
- Delta from spot offsets delta from perp
- Net delta ≈ 0 means MR1 stress test loss ≈ 0

Usage:
    python okx_portfolio_margin_monitor.py --api-key XXX --api-secret YYY --passphrase ZZZ

Requirements:
    pip install requests --break-system-packages
"""

import argparse
import base64
import hashlib
import hmac
import json
import time
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, List, Dict
import requests


# =============================================================================
# Configuration - OKX Portfolio Margin Parameters
# =============================================================================

BASE_URL = "https://www.okx.com"

# MR1 Spot Shock Parameters (from OKX documentation)
SPOT_SHOCK_PARAMS = {
    # Tier 1: BTC, ETH
    "BTC": {"max_move": 0.12, "extreme_move": 0.24},  # ±12%, ±24%
    "ETH": {"max_move": 0.12, "extreme_move": 0.24},
    # Tier 2: SOL, DOGE, etc.
    "SOL": {"max_move": 0.18, "extreme_move": 0.36},
    "DOGE": {"max_move": 0.18, "extreme_move": 0.36},
    # Default (Others)
    "DEFAULT": {"max_move": 0.25, "extreme_move": 0.50},
}

# MR4 Basis Risk Parameters
BASIS_RISK_PARAMS = {
    "BTC": {"min_charge": 0.002, "annualized_move": 0.05},  # 0.2%, 5%
    "ETH": {"min_charge": 0.002, "annualized_move": 0.05},
    "DEFAULT": {"min_charge": 0.02, "annualized_move": 0.30},
}

# Days to expiry for basis calculation
DAYS_TO_EXPIRY = {
    "SPOT": 0,
    "SWAP": 0.33,  # Perpetual treated as 0.33 days
}


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class RiskUnit:
    """Represents a Portfolio Margin risk unit."""
    underlying: str              # e.g., "BTC"
    risk_unit_type: str          # "USDT", "USDC", or "USD" (crypto-margined)
    
    # Position components
    spot_delta: float = 0.0      # Delta from spot holdings
    spot_in_use: float = 0.0     # Spot amount used for hedging
    perp_delta: float = 0.0      # Delta from perpetual positions
    futures_delta: float = 0.0   # Delta from expiry futures
    options_delta: float = 0.0   # Delta from options
    
    # Calculated deltas
    derivatives_delta: float = 0.0
    net_delta: float = 0.0
    
    # Risk metrics
    mr1_spot_shock: float = 0.0
    mr4_basis_risk: float = 0.0
    mr6_extreme_move: float = 0.0
    mr7_minimum_charge: float = 0.0
    
    # Final MMR for this risk unit
    mmr: float = 0.0
    
    @property
    def is_hedged(self) -> bool:
        """Check if position is delta-hedged."""
        return abs(self.net_delta) < abs(self.spot_delta) * 0.05  # Within 5%


@dataclass
class PortfolioMarginAccount:
    """Portfolio margin account state."""
    # Account-level metrics
    adjusted_equity: float = 0.0
    total_mmr: float = 0.0
    total_imr: float = 0.0
    margin_ratio: float = 0.0
    
    # Borrowing metrics
    borrowing_mmr: float = 0.0
    borrowing_imr: float = 0.0
    
    # Risk units
    risk_units: List[RiskUnit] = field(default_factory=list)
    
    # Spot-derivatives risk offset mode
    risk_offset_mode: str = "USDT"  # "USDT", "USDC", or "crypto"
    
    @property
    def derivatives_mmr(self) -> float:
        return sum(ru.mmr for ru in self.risk_units)
    
    @property
    def health_status(self) -> str:
        if self.margin_ratio > 300:
            return "✅ HEALTHY"
        elif self.margin_ratio > 150:
            return "⚠️  WARNING"
        elif self.margin_ratio > 100:
            return "🔴 DANGER"
        else:
            return "💀 LIQUIDATION"


@dataclass 
class StressTestResult:
    """Result of a stress test scenario."""
    scenario: str
    price_change: float
    spot_pnl: float
    perp_pnl: float
    net_pnl: float
    projected_mr1: float
    is_worst_case: bool = False


# =============================================================================
# API Client
# =============================================================================

class OKXClient:
    """OKX REST API client."""
    
    def __init__(self, api_key: str, api_secret: str, passphrase: str, demo: bool = False):
        self.api_key = api_key
        self.api_secret = api_secret
        self.passphrase = passphrase
        self.demo = demo
        self.session = requests.Session()
    
    def _sign(self, timestamp: str, method: str, path: str, body: str = "") -> str:
        message = timestamp + method + path + body
        mac = hmac.new(
            self.api_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        )
        return base64.b64encode(mac.digest()).decode('utf-8')
    
    def _request(self, method: str, path: str, params: dict = None, body: dict = None) -> dict:
        timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
        
        url = BASE_URL + path
        if params:
            query = '&'.join(f"{k}={v}" for k, v in params.items())
            path = f"{path}?{query}"
            url = f"{url}?{query}"
        
        body_str = json.dumps(body) if body else ""
        signature = self._sign(timestamp, method.upper(), path, body_str)
        
        headers = {
            'OK-ACCESS-KEY': self.api_key,
            'OK-ACCESS-SIGN': signature,
            'OK-ACCESS-TIMESTAMP': timestamp,
            'OK-ACCESS-PASSPHRASE': self.passphrase,
            'Content-Type': 'application/json',
        }
        
        if self.demo:
            headers['x-simulated-trading'] = '1'
        
        if method.upper() == 'GET':
            response = self.session.get(url, headers=headers)
        else:
            response = self.session.post(url, headers=headers, data=body_str)
        
        data = response.json()
        if data.get('code') != '0':
            raise Exception(f"API Error: {data.get('msg', 'Unknown error')} (code: {data.get('code')})")
        
        return data.get('data', [])
    
    def _public_request(self, path: str, params: dict = None) -> dict:
        url = BASE_URL + path
        if params:
            query = '&'.join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{query}"
        
        response = self.session.get(url)
        data = response.json()
        if data.get('code') != '0':
            raise Exception(f"API Error: {data.get('msg', 'Unknown error')}")
        
        return data.get('data', [])
    
    def get_account_config(self) -> dict:
        """Get account configuration."""
        data = self._request('GET', '/api/v5/account/config')
        return data[0] if data else {}
    
    def get_account_balance(self) -> dict:
        """Get full account balance data."""
        data = self._request('GET', '/api/v5/account/balance')
        return data[0] if data else {}
    
    def get_positions(self, inst_type: str = None) -> list:
        """Get all positions."""
        params = {}
        if inst_type:
            params['instType'] = inst_type
        return self._request('GET', '/api/v5/account/positions', params=params)
    
    def get_account_position_risk(self) -> list:
        """Get account position risk - includes risk unit breakdown."""
        return self._request('GET', '/api/v5/account/account-position-risk')
    
    def get_mark_price(self, inst_id: str) -> float:
        data = self._public_request('/api/v5/public/mark-price', {'instId': inst_id})
        if data:
            return float(data[0].get('markPx', 0))
        return 0.0
    
    def get_funding_rate(self, inst_id: str) -> float:
        data = self._public_request('/api/v5/public/funding-rate', {'instId': inst_id})
        if data:
            return float(data[0].get('fundingRate', 0))
        return 0.0


# =============================================================================
# Portfolio Margin Calculator
# =============================================================================

class PortfolioMarginCalculator:
    """
    Calculates Portfolio Margin risk metrics.
    
    Key insight for delta-neutral carry trade:
    - When spot delta ≈ -perp delta, net delta ≈ 0
    - MR1 (spot shock) becomes ≈ 0 because gains offset losses
    - The binding constraint becomes MR4 (basis risk) or MR7 (min charge)
    """
    
    def __init__(self, client: OKXClient):
        self.client = client
    
    def get_shock_params(self, underlying: str) -> dict:
        """Get stress test parameters for an underlying."""
        return SPOT_SHOCK_PARAMS.get(underlying, SPOT_SHOCK_PARAMS["DEFAULT"])
    
    def get_basis_params(self, underlying: str) -> dict:
        """Get basis risk parameters for an underlying."""
        return BASIS_RISK_PARAMS.get(underlying, BASIS_RISK_PARAMS["DEFAULT"])
    
    def calculate_mr1_spot_shock(
        self,
        underlying: str,
        spot_delta_usd: float,
        perp_delta_usd: float,
        current_price: float,
    ) -> tuple[float, List[StressTestResult]]:
        """
        Calculate MR1 - Spot Shock.
        
        MR1 simulates 7 price scenarios × 3 IV scenarios = 21 scenarios.
        For futures/perps only (no options), IV doesn't matter.
        
        For a delta-neutral position:
        - Spot gains when price goes up
        - Short perp loses when price goes up
        - Net P&L is approximately zero
        
        Returns:
            (max_loss, list of stress test results)
        """
        params = self.get_shock_params(underlying)
        max_move = params["max_move"]
        
        # Price scenarios: 0%, ±1/3, ±2/3, ±full of max_move
        price_moves = [
            0,
            max_move / 3,
            -max_move / 3,
            2 * max_move / 3,
            -2 * max_move / 3,
            max_move,
            -max_move,
        ]
        
        results = []
        max_loss = 0
        
        for move in price_moves:
            # Spot P&L (long spot gains when price goes up)
            spot_pnl = spot_delta_usd * move
            
            # Perp P&L (short perp loses when price goes up)
            # For USDT-margined perp, P&L is linear in price
            perp_pnl = perp_delta_usd * move
            
            # Net P&L
            net_pnl = spot_pnl + perp_pnl
            
            # MR1 is the maximum LOSS
            loss = max(0, -net_pnl)
            
            result = StressTestResult(
                scenario=f"{move*100:+.0f}%",
                price_change=move,
                spot_pnl=spot_pnl,
                perp_pnl=perp_pnl,
                net_pnl=net_pnl,
                projected_mr1=loss,
            )
            
            if loss > max_loss:
                max_loss = loss
                # Mark previous worst case as not worst
                for r in results:
                    r.is_worst_case = False
                result.is_worst_case = True
            
            results.append(result)
        
        return max_loss, results
    
    def calculate_mr4_basis_risk(
        self,
        underlying: str,
        spot_delta_usd: float,
        perp_delta_usd: float,
    ) -> float:
        """
        Calculate MR4 - Basis Risk.
        
        Basis risk captures the risk that spot and perp prices diverge.
        
        Formula:
        MR4 = Sum of |Cash Delta_t| × max(a, annualized_move × sqrt(days_to_expiry / 365))
        
        For spot + perp:
        - Spot: days_to_expiry = 0
        - Perp: days_to_expiry = 0.33
        """
        params = self.get_basis_params(underlying)
        a = params["min_charge"]
        annualized = params["annualized_move"]
        
        # Spot component (0 days to expiry)
        spot_days = DAYS_TO_EXPIRY["SPOT"]
        spot_roll_shock = max(a, annualized * math.sqrt(spot_days / 365))
        spot_basis_charge = abs(spot_delta_usd) * spot_roll_shock
        
        # Perp component (0.33 days to expiry)
        perp_days = DAYS_TO_EXPIRY["SWAP"]
        perp_roll_shock = max(a, annualized * math.sqrt(perp_days / 365))
        perp_basis_charge = abs(perp_delta_usd) * perp_roll_shock
        
        # When hedged, the deltas partially offset
        # The net basis risk is on the HEDGED amount
        hedged_amount = min(abs(spot_delta_usd), abs(perp_delta_usd))
        
        # Simplified: basis risk on the hedged notional
        # The charge is the difference in roll shock between the two legs
        basis_charge = hedged_amount * abs(spot_roll_shock - perp_roll_shock)
        
        # Plus unhedged delta
        unhedged = abs(abs(spot_delta_usd) - abs(perp_delta_usd))
        if spot_delta_usd > 0 and perp_delta_usd < 0:
            # Normal hedge: spot long, perp short
            if abs(spot_delta_usd) > abs(perp_delta_usd):
                unhedged_charge = unhedged * spot_roll_shock
            else:
                unhedged_charge = unhedged * perp_roll_shock
        else:
            unhedged_charge = unhedged * max(spot_roll_shock, perp_roll_shock)
        
        return basis_charge + unhedged_charge
    
    def calculate_mr6_extreme_move(
        self,
        underlying: str,
        spot_delta_usd: float,
        perp_delta_usd: float,
    ) -> float:
        """
        Calculate MR6 - Extreme Move.
        
        Same as MR1 but with 2x the price move.
        MR6 = 0.5 × max loss under extreme scenarios.
        
        For delta-neutral positions, this should also be near zero.
        """
        params = self.get_shock_params(underlying)
        extreme_move = params["extreme_move"]
        
        # Test both directions
        losses = []
        for move in [extreme_move, -extreme_move]:
            spot_pnl = spot_delta_usd * move
            perp_pnl = perp_delta_usd * move
            net_pnl = spot_pnl + perp_pnl
            losses.append(max(0, -net_pnl))
        
        # MR6 = half of max loss
        return max(losses) * 0.5
    
    def calculate_mr7_minimum_charge(
        self,
        perp_notional_usd: float,
        underlying: str = "BTC",
    ) -> float:
        """
        Calculate MR7 - Minimum Charge.
        
        This is the floor for MMR, covering liquidation costs.
        Raw charge = slippage + trading fees
        Then scaled by position size tiers.
        
        Simplified calculation for perpetual only.
        """
        # Approximate raw minimum charge
        # Slippage: ~0.02% for BTC
        # Trading fee: ~0.05% taker
        raw_charge_rate = 0.0007  # 0.07% total
        raw_charge = perp_notional_usd * raw_charge_rate
        
        # Apply scaling factor based on tiers
        # BTC/ETH tier config
        if underlying in ["BTC", "ETH"]:
            tiers = [
                (250_000, 1),
                (500_000, 2),
                (1_000_000, 4),
                (2_000_000, 6),
                (3_000_000, 8),
                (4_000_000, 10),
                (float('inf'), 12),
            ]
        else:
            tiers = [
                (3_000, 1),
                (8_000, 2),
                (14_000, 3),
                (float('inf'), 4),
            ]
        
        # Calculate scaled charge
        scaled_charge = 0
        remaining = raw_charge
        prev_limit = 0
        
        for limit, multiplier in tiers:
            tier_amount = min(remaining, limit - prev_limit)
            if tier_amount <= 0:
                break
            scaled_charge += tier_amount * multiplier
            remaining -= tier_amount
            prev_limit = limit
        
        return scaled_charge
    
    def calculate_risk_unit_mmr(
        self,
        underlying: str,
        spot_delta_usd: float,
        perp_delta_usd: float,
        perp_notional_usd: float,
        current_price: float,
    ) -> dict:
        """
        Calculate total MMR for a risk unit.
        
        Formula:
        Derivatives MMR = max(
            max(MR1, MR2, MR6) + MR3 + MR4 + MR5,
            MR7
        )
        
        For spot + perp (no options):
        - MR2 (theta) = 0
        - MR3 (vega) = 0
        - MR5 (interest rate) = 0
        
        So: MMR = max(max(MR1, MR6) + MR4, MR7)
        """
        mr1, stress_results = self.calculate_mr1_spot_shock(
            underlying, spot_delta_usd, perp_delta_usd, current_price
        )
        
        mr4 = self.calculate_mr4_basis_risk(
            underlying, spot_delta_usd, perp_delta_usd
        )
        
        mr6 = self.calculate_mr6_extreme_move(
            underlying, spot_delta_usd, perp_delta_usd
        )
        
        mr7 = self.calculate_mr7_minimum_charge(
            perp_notional_usd, underlying
        )
        
        # For no options: MR2 = MR3 = MR5 = 0
        mr2 = 0
        mr3 = 0
        mr5 = 0
        
        # Calculate MMR
        risk_based = max(mr1, mr2, mr6) + mr3 + mr4 + mr5
        mmr = max(risk_based, mr7)
        
        # Determine binding constraint
        if mr7 > risk_based:
            binding_constraint = "MR7 (Minimum Charge)"
        elif mr4 > max(mr1, mr6):
            binding_constraint = "MR4 (Basis Risk)"
        elif mr1 > mr6:
            binding_constraint = "MR1 (Spot Shock)"
        else:
            binding_constraint = "MR6 (Extreme Move)"
        
        return {
            "mr1": mr1,
            "mr2": mr2,
            "mr3": mr3,
            "mr4": mr4,
            "mr5": mr5,
            "mr6": mr6,
            "mr7": mr7,
            "mmr": mmr,
            "risk_based": risk_based,
            "binding_constraint": binding_constraint,
            "stress_results": stress_results,
        }


# =============================================================================
# Portfolio Margin Monitor
# =============================================================================

class PortfolioMarginMonitor:
    """Main monitoring class for Portfolio Margin mode."""
    
    def __init__(self, client: OKXClient):
        self.client = client
        self.calculator = PortfolioMarginCalculator(client)
    
    def print_header(self, text: str):
        print(f"\n{'='*70}")
        print(f"  {text}")
        print('='*70)
    
    def print_section(self, text: str):
        print(f"\n  --- {text} ---")
    
    def run_full_report(self):
        """Generate comprehensive Portfolio Margin report."""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        self.print_header(f"OKX PORTFOLIO MARGIN MONITOR - {timestamp}")
        
        # Account configuration
        config = self.client.get_account_config()
        acct_mode = config.get('acctLv', 'unknown')
        mode_names = {'1': 'Simple', '2': 'Single-currency', '3': 'Multi-currency', '4': 'Portfolio'}
        print(f"\n  Account Mode: {mode_names.get(acct_mode, acct_mode)}")
        
        if acct_mode != '4':
            print(f"\n  ⚠️  WARNING: Account is not in Portfolio Margin mode!")
            print(f"     This monitor is designed for Portfolio Margin.")
            print(f"     Switch to Portfolio Margin for optimal margin efficiency.")
        
        # Get spot-derivatives risk offset mode
        spot_deriv_mode = config.get('spotOffsetType', '')
        offset_modes = {'1': 'USDT', '2': 'Crypto', '3': 'USDC'}
        print(f"  Spot-Derivatives Offset: {offset_modes.get(spot_deriv_mode, 'Disabled')}")
        
        # Fetch data
        balance_data = self.client.get_account_balance()
        positions = self.client.get_positions()
        
        # Extract key metrics
        adj_eq = float(balance_data.get('adjEq', 0))
        total_eq = float(balance_data.get('totalEq', 0))
        imr = float(balance_data.get('imr', 0))
        mmr = float(balance_data.get('mmr', 0))
        mgn_ratio = float(balance_data.get('mgnRatio', 0)) * 100
        
        # Find BTC positions
        btc_spot = None
        btc_perp = None
        
        for detail in balance_data.get('details', []):
            if detail.get('ccy') == 'BTC':
                btc_spot = {
                    'equity': float(detail.get('eq', 0)),
                    'usd_value': float(detail.get('eqUsd', 0)),
                    'spot_in_use': float(detail.get('spotInUseAmt', 0)),
                }
        
        for pos in positions:
            if 'BTC-USDT' in pos.get('instId', '') and 'SWAP' in pos.get('instId', ''):
                btc_perp = {
                    'size': float(pos.get('pos', 0)),
                    'notional': float(pos.get('notionalUsd', 0)),
                    'mark_price': float(pos.get('markPx', 0)),
                    'upl': float(pos.get('upl', 0)),
                    'delta': float(pos.get('deltaBS', 0)) if pos.get('deltaBS') else float(pos.get('pos', 0)),
                }
        
        # Account Summary
        self.print_section("ACCOUNT SUMMARY")
        status = "✅ HEALTHY" if mgn_ratio > 300 else ("⚠️ WARNING" if mgn_ratio > 100 else "🔴 DANGER")
        print(f"  Status:              {status}")
        print(f"  Margin Ratio:        {mgn_ratio:.2f}%")
        print(f"  Distance to Liq:     {mgn_ratio - 100:+.2f}%")
        print()
        print(f"  Adjusted Equity:     ${adj_eq:,.2f}")
        print(f"  Total Equity:        ${total_eq:,.2f}")
        print(f"  Initial Margin:      ${imr:,.2f}")
        print(f"  Maintenance Margin:  ${mmr:,.2f}")
        
        # Position Analysis
        self.print_section("DELTA-NEUTRAL POSITION ANALYSIS")
        
        if btc_spot and btc_perp:
            spot_delta_usd = btc_spot['usd_value']
            perp_delta_usd = btc_perp['size'] * btc_perp['mark_price']  # Negative for short
            net_delta_usd = spot_delta_usd + perp_delta_usd
            
            print(f"\n  BTC Risk Unit (USDT-margined)")
            print(f"  {'─'*50}")
            print(f"  Spot BTC Delta:      ${spot_delta_usd:>+15,.2f}")
            print(f"  Perp Delta:          ${perp_delta_usd:>+15,.2f}")
            print(f"  Net Delta:           ${net_delta_usd:>+15,.2f}")
            print(f"  Hedge Ratio:         {abs(perp_delta_usd/spot_delta_usd)*100:.1f}%" if spot_delta_usd else "N/A")
            
            if btc_spot.get('spot_in_use'):
                print(f"  Spot In Use:         {btc_spot['spot_in_use']:.6f} BTC")
            
            # Calculate risk metrics
            self.print_section("RISK METRIC CALCULATION (MR1-MR7)")
            
            risk_metrics = self.calculator.calculate_risk_unit_mmr(
                underlying="BTC",
                spot_delta_usd=spot_delta_usd,
                perp_delta_usd=perp_delta_usd,
                perp_notional_usd=btc_perp['notional'],
                current_price=btc_perp['mark_price'],
            )
            
            print(f"\n  MR1 (Spot Shock):      ${risk_metrics['mr1']:>12,.2f}")
            print(f"  MR4 (Basis Risk):      ${risk_metrics['mr4']:>12,.2f}")
            print(f"  MR6 (Extreme Move):    ${risk_metrics['mr6']:>12,.2f}")
            print(f"  MR7 (Min Charge):      ${risk_metrics['mr7']:>12,.2f}")
            print(f"  {'─'*40}")
            print(f"  Risk-Based MMR:        ${risk_metrics['risk_based']:>12,.2f}")
            print(f"  Final MMR:             ${risk_metrics['mmr']:>12,.2f}")
            print(f"\n  Binding Constraint:    {risk_metrics['binding_constraint']}")
            
            # Stress Test Results
            self.print_section("MR1 STRESS TEST SCENARIOS")
            print(f"\n  {'Scenario':>10} {'Spot P&L':>14} {'Perp P&L':>14} {'Net P&L':>14} {'Loss':>12}")
            print(f"  {'-'*10} {'-'*14} {'-'*14} {'-'*14} {'-'*12}")
            
            for result in risk_metrics['stress_results']:
                marker = "◀ MAX" if result.is_worst_case else ""
                print(f"  {result.scenario:>10} ${result.spot_pnl:>+13,.0f} ${result.perp_pnl:>+13,.0f} "
                      f"${result.net_pnl:>+13,.0f} ${result.projected_mr1:>11,.0f} {marker}")
            
            # Why delta-neutral is efficient
            self.print_section("WHY YOUR POSITION IS MARGIN-EFFICIENT")
            
            hedge_efficiency = abs(net_delta_usd) / spot_delta_usd if spot_delta_usd else 0
            
            if hedge_efficiency < 0.05:
                print("""
  ✅ EXCELLENT HEDGE
  
  Your position is delta-neutral, which means:
  
  1. MR1 (Spot Shock) ≈ $0
     When BTC moves ±12%, your spot gains/losses are offset by perp losses/gains.
     The stress test shows near-zero P&L in all scenarios.
  
  2. MR6 (Extreme Move) ≈ $0  
     Same logic applies to the ±24% extreme scenario.
  
  3. Your MMR is driven by MR4 (Basis Risk) or MR7 (Min Charge)
     - MR4: Risk that spot and perp prices diverge
     - MR7: Minimum charge for liquidation costs
  
  This is MUCH more efficient than Multi-currency Margin mode, which treats
  your spot and perp as separate positions with no hedge recognition.""")
            else:
                print(f"""
  ⚠️  PARTIAL HEDGE ({(1-hedge_efficiency)*100:.1f}% unhedged)
  
  Your position has residual delta exposure. Consider:
  - Adjusting perp size to match spot exactly
  - MR1 and MR6 will charge for the unhedged portion""")
            
            # Comparison with Multi-currency
            self.print_section("MARGIN MODE COMPARISON")
            
            # Multi-currency would use ~3% IMR on perp notional (at 33x leverage)
            multi_currency_imr = btc_perp['notional'] * 0.03
            portfolio_imr = risk_metrics['mmr'] * 1.3  # IMR = 1.3 × MMR
            
            savings = multi_currency_imr - portfolio_imr
            savings_pct = (savings / multi_currency_imr) * 100 if multi_currency_imr > 0 else 0
            
            print(f"\n  Estimated Multi-Currency IMR:   ${multi_currency_imr:>12,.2f}")
            print(f"  Portfolio Margin IMR:           ${portfolio_imr:>12,.2f}")
            print(f"  {'─'*45}")
            print(f"  Margin Savings:                 ${savings:>12,.2f} ({savings_pct:.1f}%)")
            
        else:
            print("\n  ⚠️  Could not find BTC spot + BTC-USDT-SWAP positions")
            print("     This monitor is designed for delta-neutral carry trades.")
        
        # Funding Rate
        self.print_section("FUNDING INCOME")
        try:
            funding_rate = self.client.get_funding_rate('BTC-USDT-SWAP')
            if btc_perp and funding_rate:
                # Short position earns positive funding
                funding_direction = "EARNING" if (btc_perp['size'] < 0 and funding_rate > 0) or \
                                                  (btc_perp['size'] > 0 and funding_rate < 0) else "PAYING"
                daily_funding = abs(btc_perp['notional'] * funding_rate * 3)
                annual_yield = abs(funding_rate * 3 * 365 * 100)
                
                print(f"\n  Current 8h Rate:     {funding_rate*100:.4f}%")
                print(f"  Direction:           {funding_direction}")
                print(f"  Daily Funding:       ${daily_funding:,.2f}")
                print(f"  Annualized Yield:    {annual_yield:.2f}%")
        except Exception as e:
            print(f"\n  Could not fetch funding rate: {e}")
        
        # Risks
        self.print_section("KEY RISKS IN PORTFOLIO MARGIN")
        print("""
  1. MR4 (Basis Risk) - The main margin charge for your position
     - Basis can widen during volatility
     - OKX charges 0.2% minimum + time-scaled volatility
  
  2. MR7 (Minimum Charge) - Scales with position size
     - Large positions have higher scaling factors
     - Check tier configuration for your size
  
  3. MR9 (Stablecoin Depeg) - If USDT depegs from USD
     - Your USDT-margined position vs USD spot creates risk
     - Monitor USDT peg during market stress
  
  4. Funding Rate Flip
     - Negative funding means shorts pay longs
     - Your carry trade becomes costly
        """)
        
        print("\n" + "="*70 + "\n")


# =============================================================================
# CLI Entry Point
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='OKX Portfolio Margin Delta-Neutral Monitor',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This monitor is optimized for Portfolio Margin mode with Spot-Derivatives
Risk Offset enabled. It calculates MR1-MR7 to show why your delta-neutral
position is margin-efficient.

Examples:
  python okx_portfolio_margin_monitor.py --api-key XXX --api-secret YYY --passphrase ZZZ
  python okx_portfolio_margin_monitor.py --demo  # Use demo trading
        """
    )
    
    parser.add_argument('--api-key', help='OKX API key')
    parser.add_argument('--api-secret', help='OKX API secret')
    parser.add_argument('--passphrase', help='OKX API passphrase')
    parser.add_argument('--demo', action='store_true', help='Use demo trading')
    parser.add_argument('--loop', type=int, default=0, help='Refresh interval in seconds')
    
    args = parser.parse_args()
    
    import os
    api_key = args.api_key or os.environ.get('OKX_API_KEY')
    api_secret = args.api_secret or os.environ.get('OKX_API_SECRET')
    passphrase = args.passphrase or os.environ.get('OKX_PASSPHRASE')
    
    if not all([api_key, api_secret, passphrase]):
        parser.error("API credentials required")
    
    client = OKXClient(api_key, api_secret, passphrase, demo=args.demo)
    monitor = PortfolioMarginMonitor(client)
    
    try:
        while True:
            monitor.run_full_report()
            if args.loop <= 0:
                break
            print(f"Refreshing in {args.loop} seconds...")
            time.sleep(args.loop)
    except KeyboardInterrupt:
        print("\nMonitoring stopped.")


if __name__ == '__main__':
    main()
