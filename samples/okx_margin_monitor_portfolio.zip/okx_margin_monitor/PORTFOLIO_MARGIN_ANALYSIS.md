# Portfolio Margin vs Multi-Currency Margin for Delta-Neutral Carry Trades

## Executive Summary

For a **spot BTC + short BTC-USDT perpetual** delta-neutral position, Portfolio Margin mode is significantly more capital efficient than Multi-currency Margin mode because it **explicitly recognizes the hedge**.

| Aspect | Multi-Currency | Portfolio Margin |
|--------|----------------|------------------|
| Hedge Recognition | ❌ None - positions treated gross | ✅ Full - delta offsets recognized |
| Margin Calculation | Position tiers (% of notional) | Stress tests (MR1-MR7) |
| MMR for Delta-Neutral | ~3% of notional | ~0.2-0.5% of notional |
| Margin Efficiency | Lower | **5-10x better** |
| Minimum Equity | None | $10,000 USD |

---

## How Multi-Currency Margin Works

In Multi-currency mode, your position is treated **GROSS**:

```
┌─────────────────────────────────────────────────────────────────┐
│                   MULTI-CURRENCY MARGIN                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   SPOT BTC (1 BTC @ $100,000)                                   │
│   ────────────────────────────                                   │
│   Contributes to adjEq: $100,000 × 97% = $97,000                │
│   (3% haircut via discount rate)                                 │
│                                                                  │
│   SHORT BTC-USDT-SWAP (-1 BTC)                                  │
│   ────────────────────────────                                   │
│   Consumes margin: $100,000 × 3% = $3,000 MMR                   │
│   (Based on position tier)                                       │
│                                                                  │
│   ═══════════════════════════════════════════════════════════   │
│   NO RECOGNITION that these positions offset each other!         │
│   Margin ratio = adjEq / MMR = $97,000 / $3,000 = 3,233%        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Key Multi-Currency Characteristics

1. **Spot as Collateral Only**
   - Your spot BTC provides `adjEq` (adjusted equity)
   - Haircut applied via discount rate (~97% for BTC tier 1)
   
2. **Perp Consumes Margin**
   - Margin requirement based on position tier
   - ~3% MMR at reasonable leverage
   
3. **No Hedge Benefit**
   - The fact that spot + short perp = neutral delta is **not recognized**
   - You're essentially over-collateralized

### Multi-Currency During a Crash

When BTC drops 20%:

| Component | Change | Effect on Account |
|-----------|--------|-------------------|
| Spot BTC value | -$20,000 | adjEq drops by $19,400 (after 97% discount) |
| Short perp PnL | +$20,000 USDT | adjEq rises by $20,000 (USDT has 100% credit) |
| Net effect | +$600 | Margin ratio **improves slightly** |

The asymmetry (97% vs 100%) actually helps you in crashes, but you're still paying unnecessary margin.

---

## How Portfolio Margin Works

In Portfolio Margin mode with **Spot-Derivatives Risk Offset**, your hedge is **explicitly recognized**:

```
┌─────────────────────────────────────────────────────────────────┐
│                    PORTFOLIO MARGIN                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   BTC-USDT RISK UNIT                                            │
│   ══════════════════                                             │
│                                                                  │
│   ┌─────────────┐     HEDGE     ┌─────────────┐                 │
│   │ Spot BTC    │ ◄───────────► │ Short Perp  │                 │
│   │ Delta: +$100k │              │ Delta: -$100k│                 │
│   └─────────────┘               └─────────────┘                 │
│           │                           │                          │
│           └───────────┬───────────────┘                          │
│                       ▼                                          │
│              Net Delta: ≈ $0                                     │
│                                                                  │
│   ═══════════════════════════════════════════════════════════   │
│   STRESS TEST (MR1): What happens if BTC moves ±12%?            │
│   • Spot gains $12,000, Perp loses $12,000 → Net: $0            │
│   • MR1 = $0 (no loss in any scenario)                          │
│                                                                  │
│   MMR = max(MR1 + MR4, MR7) ≈ MR4 or MR7                        │
│   Typically $500-2,000 vs $3,000 in Multi-currency              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Risk Metrics (MR1-MR9)

Portfolio Margin calculates MMR via stress tests:

| Risk Metric | Description | For Delta-Neutral |
|-------------|-------------|-------------------|
| **MR1** | Spot shock (±12% for BTC) | ≈ $0 (hedged) |
| MR2 | Theta decay (options only) | $0 |
| MR3 | Vega risk (options only) | $0 |
| **MR4** | Basis risk (spot vs perp divergence) | ~0.2% of notional |
| MR5 | Interest rate risk (options only) | $0 |
| **MR6** | Extreme move (±24% for BTC) | ≈ $0 (hedged) |
| **MR7** | Minimum charge (liquidation costs) | ~0.07% × scaling |
| MR8 | Borrowing margin | $0 (no borrowing) |
| MR9 | Stablecoin depeg risk | Minimal if USDT stable |

**Formula:**
```
Derivatives MMR = max(
    max(MR1, MR2, MR6) + MR3 + MR4 + MR5 + MR9,
    MR7
)
```

For spot + perp (no options):
```
MMR = max(max(MR1, MR6) + MR4, MR7)
    = max(0 + MR4, MR7)  # Because MR1 ≈ MR6 ≈ 0 when hedged
    = max(MR4, MR7)
```

### MR1 Stress Test Detail

OKX simulates 7 price scenarios × 3 IV scenarios = 21 scenarios:

| Scenario | BTC Price Move | Spot P&L | Perp P&L | Net P&L | Loss |
|----------|----------------|----------|----------|---------|------|
| 1 | 0% | $0 | $0 | $0 | $0 |
| 2 | +4% | +$4,000 | -$4,000 | $0 | $0 |
| 3 | -4% | -$4,000 | +$4,000 | $0 | $0 |
| 4 | +8% | +$8,000 | -$8,000 | $0 | $0 |
| 5 | -8% | -$8,000 | +$8,000 | $0 | $0 |
| 6 | +12% | +$12,000 | -$12,000 | $0 | $0 |
| 7 | -12% | -$12,000 | +$12,000 | $0 | $0 |

**MR1 = max(all losses) = $0** ✅

### MR4 Basis Risk Calculation

Basis risk captures spot-perp price divergence:

```
MR4 = |Cash Delta| × max(a, annualized_move × sqrt(days/365))

Where:
- a = 0.2% (minimum for BTC)
- annualized_move = 5% (for BTC)
- days_to_expiry: Spot = 0, Perp = 0.33

For $100,000 notional:
- Spot component: $100,000 × 0.2% = $200
- Perp component: $100,000 × max(0.2%, 5% × sqrt(0.33/365)) = $200

With hedging, the net basis charge is much lower.
```

### MR7 Minimum Charge

Floor for MMR to cover liquidation costs:

```
Raw charge = Notional × (slippage + fees) ≈ 0.07%
Scaled by position tier multipliers

For $100,000 BTC perp:
- Raw: $100,000 × 0.07% = $70
- Tier 1 (< $250k): multiplier = 1
- MR7 = $70
```

---

## Margin Comparison Example

**Position: 1 BTC spot + 1 BTC short perp @ $100,000**

### Multi-Currency Margin

| Component | Calculation | Value |
|-----------|-------------|-------|
| Spot BTC (collateral) | $100,000 × 97% discount | $97,000 adjEq |
| Perp MMR | $100,000 × 3% (position tier) | $3,000 |
| **Margin Ratio** | $97,000 / $3,000 | **3,233%** |

### Portfolio Margin

| Risk Metric | Calculation | Value |
|-------------|-------------|-------|
| MR1 (Spot Shock) | Stress test: ±12% moves | ≈ $0 |
| MR4 (Basis Risk) | $100,000 × 0.3% | $300 |
| MR6 (Extreme) | Stress test: ±24% moves | ≈ $0 |
| MR7 (Min Charge) | $100,000 × 0.07% × 1 | $70 |
| **Total MMR** | max(0 + $300, $70) | **$300** |
| IMR | 1.3 × $300 | $390 |

### Efficiency Gain

```
Multi-Currency MMR:  $3,000
Portfolio MMR:       $300
────────────────────────────
Savings:             $2,700 (90%!)
```

---

## When Portfolio Margin Loses Its Advantage

Portfolio Margin isn't always better:

### 1. Small Positions

MR7 minimum charge has a floor. For very small positions (< $10,000), the minimum charge may exceed the risk-based margin.

### 2. Unhedged Positions

If you only have spot or only have perp (not both), MR1 will be non-zero:

```
1 BTC spot only (no perp):
MR1 = $100,000 × 12% = $12,000

This is WORSE than Multi-currency!
```

### 3. Large Position Tiers

MR7 scaling increases with size. For very large positions:

| BTC Notional | MR7 Multiplier | Effect |
|--------------|----------------|--------|
| < $250k | 1× | Baseline |
| $250k-500k | 2× | 2× higher |
| $500k-1M | 4× | 4× higher |
| > $4M | 12× | 12× higher |

### 4. Stablecoin Depeg (MR9)

If USDT depegs, MR9 charges significant margin:

| USDT Price | MR9 Factor (Tier 1) |
|------------|---------------------|
| > $0.995 | 0.5% |
| $0.99 | 0.5% |
| $0.98 | 1% |
| $0.95 | 5% |
| $0.90 | 30% |

---

## Recommendations

### Use Portfolio Margin When:

✅ You have > $10,000 equity (required minimum)
✅ You run delta-neutral or hedged strategies
✅ You want maximum capital efficiency
✅ You understand the MR1-MR9 mechanics

### Use Multi-Currency When:

✅ You have < $10,000 equity
✅ You run directional (unhedged) strategies
✅ You want simpler margin calculation
✅ You're not optimizing for capital efficiency

### Configuration for Carry Trade

1. **Enable Portfolio Margin Mode**
   - Settings → Account Mode → Portfolio Margin
   - Requires $10,000 minimum equity

2. **Enable Spot-Derivatives Risk Offset**
   - For BTC spot + BTC-USDT-SWAP: Use "USDT" offset mode
   - Settings → Spot-Derivatives Offset → USDT

3. **Monitor "Spot In Use"**
   - Check that your spot is being used for hedging
   - Should show in Assets tab

4. **Use Position Builder**
   - Simulate margin before placing orders
   - Compare MMR with and without hedge

---

## API Endpoints for Monitoring

| Endpoint | Purpose |
|----------|---------|
| `GET /api/v5/account/config` | Check acctLv=4 for Portfolio Margin |
| `GET /api/v5/account/balance` | Total adjEq, MMR, IMR, margin ratio |
| `GET /api/v5/account/positions` | Position details including delta |
| `GET /api/v5/account/account-position-risk` | Risk unit breakdown |
| `GET /api/v5/public/discount-rate-interest-free-quota` | Discount rates |

---

## Summary

For a delta-neutral carry trade (spot BTC + short BTC-USDT perp):

| Metric | Multi-Currency | Portfolio Margin |
|--------|----------------|------------------|
| Hedge Recognition | ❌ No | ✅ Yes |
| MMR Calculation | % of notional | Stress test |
| Typical MMR | ~3% | ~0.3% |
| Capital Efficiency | 1× | 10× |
| Complexity | Simple | Advanced |
| Minimum Equity | None | $10,000 |

**Bottom line:** If you're running a carry trade with >$10k, Portfolio Margin with Spot-Derivatives Risk Offset is dramatically more capital efficient.
